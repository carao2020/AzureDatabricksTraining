# Databricks notebook source
# MAGIC %md
# MAGIC # Mounting a storage container onto DBFS

# COMMAND ----------

storageAccount = "carao2023blobstorage1"
storageKey = "RYZ26S+5WK1pp985GgQgS1hDlhFcYFLWUKqDVyEQYjYEe21Q024+JJp/moiGd9SaW6QuEE8AHkb0+ASt8btpag=="
mountPoint = "/mnt/Blob"
storageEndPoint = "wasbs://rawdata@{}.blob.core.windows.net".format(storageAccount)
storageConnectionString = "fs.azure.account.key.{}.blob.core.windows.net".format(
    storageAccount
)

try:

    dbutils.fs.mount(
        source=storageEndPoint,
        mount_point=mountPoint,
        extra_configs={storageConnectionString: storageKey}
    )


except:
    print("Already mounted")

# COMMAND ----------

# MAGIC %fs ls /mnt/Blob

# COMMAND ----------

display(dbutils.fs.ls("/mnt/Blob"))

# COMMAND ----------

ordersDataFrame=spark.read.format("csv").option("header", True).load("dbfs:/mnt/Blob/Orders.csv")

ordersDataFrame.show()

display(ordersDataFrame.limit(10))


# COMMAND ----------

dbutils.fs.unmount("/mnt/Blob")