# Databricks notebook source
storageAccount="sriniadlsgen2999"
mountpoint = "/mnt/Gen2"
storageEndPoint ="abfss://rawdata@{}.dfs.core.windows.net/".format(storageAccount)
print ('Mount Point ='+mountpoint)

#ClientId, TenantId and Secret is for the Application(ADLSGen2App) was have created as part of this recipe
clientID ="c8af7163-2d53-45b7-add9-16296f29ba72"
tenantID ="8f264c1d-6340-44fd-9e9f-e71f7d31df64"
clientSecret ="D7V8Q~M1GL4~DQLHWJlrom~pw~fIULJMOdU.6a3P"
oauth2Endpoint = "https://login.microsoftonline.com/{}/oauth2/token".format(tenantID)


configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": clientID,
           "fs.azure.account.oauth2.client.secret": clientSecret,
           "fs.azure.account.oauth2.client.endpoint": oauth2Endpoint}

try:
  dbutils.fs.mount(
  source = storageEndPoint,
  mount_point = mountpoint,
  extra_configs = configs)
except:
    print("Already mounted...."+mountpoint)


# COMMAND ----------

display(dbutils.fs.ls("/mnt/Gen2/Customer/parquetFiles"))

# COMMAND ----------

db = "tpchdb"
 
spark.sql(f"CREATE DATABASE IF NOT EXISTS {db}")
spark.sql(f"USE {db}")
 
spark.sql("SET spark.databricks.delta.formatCheck.enabled = false")
spark.sql("SET spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true")

# COMMAND ----------

import random
from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading Customer parquet files from the mount point and writing to Delta tables.

# COMMAND ----------

#Reading parquet files and adding a new column to the dataframe and writing to delta table
cust_path = "/mnt/Gen2/Customer/parquetFiles"
 
df_cust = (spark.read.format("parquet").load(cust_path)
      .withColumn("timestamp", current_timestamp()))
 
df_cust.write.format("delta").option("mergeSchema","true").mode("overwrite").save("/mnt/Gen2/Customer/delta")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Creating Delta table 
# MAGIC DROP TABLE IF EXISTS Customer;
# MAGIC CREATE TABLE Customer
# MAGIC USING delta
# MAGIC location "/mnt/Gen2/Customer/delta"

# COMMAND ----------

# MAGIC %sql
# MAGIC describe  Customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Customer limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC -- DML Operations
# MAGIC -- Deleting from Delta table
# MAGIC DELETE FROM Customer WHERE C_CUSTKEY=82533

# COMMAND ----------

#dbutils.fs.unmount("/mnt/Gen2")