# Databricks notebook source
# MAGIC %md
# MAGIC ### Create a table in Azure SQL Server DB
# MAGIC 
# MAGIC <p>
# MAGIC <br>CREATE TABLE [dbo].[CUSTOMER](
# MAGIC <br>[C_CUSTKEY] [int] NULL,
# MAGIC <br>[C_NAME] [varchar](25) NULL,
# MAGIC <br>[C_ADDRESS] [varchar](40) NULL,
# MAGIC <br>[C_NATIONKEY] [smallint] NULL,
# MAGIC <br>[C_PHONE] [char](15) NULL,
# MAGIC <br>[C_ACCTBAL] [decimal](18, 0) NULL,
# MAGIC <br>[C_MKTSEGMENT] [char](10) NULL,
# MAGIC <br>[C_COMMENT] [varchar](117) NULL
# MAGIC <br>) ON [PRIMARY]
# MAGIC <br>GO
# MAGIC </p>

# COMMAND ----------

#import the library for defininf schemas
#schemas are data structures - internally Structs

from pyspark.sql.types import *

# COMMAND ----------

logicalServerName="sqlservercarao2023"
databaseName="sqldbcarao2023"
tableName="dbo.CUSTOMER"
userName="carao2023admin"
password="Welcome123$"
jdbcUrl="jdbc:sqlserver://sqlservercarao2023.database.windows.net:1433;database=sqldbcarao2023;user=carao2023admin@sqlservercarao2023;password=Welcome123$;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"

connectionProperties={
    "user":userName,
    "password":password,
    "driver":"com.microsoft.sqlserver.jdbc.SQLServerDriver"
}


# COMMAND ----------

#schema to read CSVFiles

cust_schema = StructType(
    [
        StructField("C_CUSTKEY", IntegerType()),
        StructField("C_NAME", StringType()),
        StructField("C_ADDRESS", StringType()),
        StructField("C_NATIONKEY", ShortType()),
        StructField("C_PHONE", StringType()),
        StructField("C_ACCTBAL", DoubleType()),
        StructField("C_MKTSEGMENT", StringType()),
        StructField("C_COMMENT", StringType()),
    ]
)

# COMMAND ----------

df_cust=spark.read.format("csv").option("header", True).schema(cust_schema).load("dbfs:/mnt/Gen2/customer/csvFiles")

display(df_cust.limit(10))


# COMMAND ----------

# Reading the data from Azure SQLDB using Spark Native JDBC Connector
#If you get login error, whitelist the IP Address in SQL Server
#You must not see any records but schema must be available.

df_jdbcRead=spark.read.jdbc(jdbcUrl, table=tableName, properties=connectionProperties)
display(df_jdbcRead.printSchema());

display(df_jdbcRead.limit(100))


# COMMAND ----------

#Writing the dataframe to SQL Server
df_cust.write.jdbc(jdbcUrl, mode="append", table=tableName, properties=connectionProperties)


