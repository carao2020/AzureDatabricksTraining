# Databricks notebook source
# MAGIC %md
# MAGIC # Mounting ADLSGen2 storage account onto DBFS with RBAC and Direct Access

# COMMAND ----------

storageAccount = "carao2023blobadlsgen2"
mountPoint = "/mnt/Gen2"
storageEndPoint = "abfss://rawdata@{}.dfs.core.windows.net".format(storageAccount)

#ClientId, TenantId and Secret is for the Application(ADLSGen2App) was have created as part of this recipe
clientID ="76ab9d9c-90cd-4d1d-8f06-f27293b6c598"
tenantID ="3bf3cf81-25c1-49e5-8989-85ec9cfda95a"
clientSecret ="2vC8Q~CqgqkRL1UM_zLg3kvcALG1OovBBdlkocuY"
oauth2Endpoint = "https://login.microsoftonline.com/{}/oauth2/token".format(tenantID)

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": clientID,
           "fs.azure.account.oauth2.client.secret": clientSecret,
           "fs.azure.account.oauth2.client.endpoint": oauth2Endpoint}

try:

    dbutils.fs.mount(
        source=storageEndPoint,
        mount_point=mountPoint,
        extra_configs=configs
    )
except:
    print("Already mounted...."+mountpoint)

# COMMAND ----------

# MAGIC %fs ls /mnt/Gen2

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/mnt/Gen2/customer/csvFiles"))

# COMMAND ----------

df_cust = spark.read.format("csv").option("header", True).load("dbfs:/mnt/Gen2/customer/csvFiles")

#display count of records loaded onto dataframe
display(df_cust.count())


# COMMAND ----------

#Display the first 10 records
display(df_cust.limit(10))

#Display schema
display(df_cust.printSchema())

# COMMAND ----------

#import the library for defininf schemas
#schemas are data structures - internally Structs
from pyspark.sql.types import *


# COMMAND ----------

# create your own schema
cust_schema = StructType(
    [
        StructField("C_CUSTKEY", IntegerType()),
        StructField("C_NAME", StringType()),
        StructField("C_ADDRESS", StringType()),
        StructField("C_NATIONKEY", ShortType()),
        StructField("C_PHONE", StringType()),
        StructField("C_ACCTBAL", DoubleType()),
        StructField("C_MKTSEGMENT", StringType()),
        StructField("C_COMMENT", StringType()),
    ]
)

# COMMAND ----------

# read the data and enforce your custom schema

df_cust=spark.read.format("csv").option("header",True).schema(cust_schema).load("dbfs:/mnt/Gen2/customer/csvFiles")

display(df_cust.count())

display(df_cust.printSchema())


# COMMAND ----------

from  pyspark.sql.functions import sum, avg, max, col

# COMMAND ----------

# Powerful feature is aggregation
# in conventional RDBMS we use SQL Queries to get Aggregate Data
# Account Bal based on the Market Segment

df_cust_agg = (
    df_cust.groupBy("C_MKTSEGMENT")
    .agg(
        sum("C_ACCTBAL").cast("decimal(20,3)").alias("sum_acctbal"),
        avg("C_ACCTBAL").alias("avg_acctbal"),
        max("C_ACCTBAL").alias("max_acctbal"),
    )
    .orderBy("avg_acctbal", ascending=False)
)


df_cust_agg.show()

# COMMAND ----------

#Write the aggregate data as a blob into the /mnt/Gen2/CustMarketSegmentAgg/

df_cust_agg.write.mode("overwrite").option("header", True).csv("/mnt/Gen2/CustMarketSegmentAgg")



# COMMAND ----------

df_custAgg=spark.read.format("csv").option("header", True).csv("/mnt/Gen2/CustMarketSegmentAgg")

df_custAgg.show()


# COMMAND ----------

dbutils.fs.unmount("/mnt/Gen2")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # Access files directly from ADLS Gen2 without mounting to DBFS and using OAuth

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.carao2023blobadlsgen2.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.carao2023blobadlsgen2.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.carao2023blobadlsgen2.dfs.core.windows.net", clientID)
spark.conf.set("fs.azure.account.oauth2.client.secret.carao2023blobadlsgen2.dfs.core.windows.net", clientSecret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.carao2023blobadlsgen2.dfs.core.windows.net", oauth2Endpoint)

# COMMAND ----------

df_direct = spark.read.format("csv").option("header", True).schema(cust_schema).load("abfss://rawdata@carao2023blobadlsgen2.dfs.core.windows.net/customer/csvFiles")
display(df_direct.limit(10))


# COMMAND ----------

# MAGIC %md
# MAGIC # Converting Files into Parquet and Persisting to Storage

# COMMAND ----------

parquetCustomerDestDirect = "abfss://rawdata@carao2023blobadlsgen2.dfs.core.windows.net/customer/parquetFiles"
# read number of partitions
df_direct.rdd.getNumPartitions()
#repartition the dataframe and store it into new Dataframe
df_direct_repart10 = df_direct.repartition(10);
# read number of partitions
df_direct_repart10.rdd.getNumPartitions()
# write the repartitioned file to the destination
df_direct_repart10.write.mode("overwrite").option("header","true").parquet(parquetCustomerDestDirect)

display(dbutils.fs.ls("abfss://rawdata@carao2023blobadlsgen2.dfs.core.windows.net/customer/parquetFiles"))

# COMMAND ----------

df_direct_parquet = spark.read.format("parquet").option("header", True).schema(cust_schema).load("abfss://rawdata@carao2023blobadlsgen2.dfs.core.windows.net/customer/parquetFiles")
display(df_direct_parquet.limit(10000))


# COMMAND ----------

#dbutils.fs.ls ("file:/root/")
display(dbutils.fs.mounts())

# COMMAND ----------

storageConnString="fs.azure.sas.rawdata.carao2023blobadlsgen2.blob.core.windows.net"
spark.conf.set(storageConnString, "?sv=2021-06-08&ss=bfqt&srt=s&sp=rwdlacupyx&se=2022-11-23T18:03:29Z&st=2022-11-23T10:03:29Z&spr=https&sig=1iGvoC%2BdB5IkCyTnc7cR0RuZuWEgCP7evJ3ReCwOq%2FA%3D")

# COMMAND ----------

storageEndPointFolders = "{}/customer".format(storageEndPoint)
display(dbutils.fs.ls(storageEndPointFolders))