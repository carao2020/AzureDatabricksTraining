# Databricks notebook source
# MAGIC %md 
# MAGIC #  Reading using kafka for Azure EventHub

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

#Eventhub namespace and required keys
#EH_NAMESPACE_NAME = "carao2023eventhub"
#EH_KEY_NAME = "readwrite"
#EH_KEY_VALUE = "eOlZaWO4qP/etM4GPkOcw98vbZXb6JLXPmUrpBJdSOQ="
# connection string of Event Hubs Namespace
connectionString = "Endpoint=sb://carao2023eventhub.servicebus.windows.net/;SharedAccessKeyName=readwrite;SharedAccessKey=eOlZaWO4qP/etM4GPkOcw98vbZXb6JLXPmUrpBJdSOQ=;EntityPath=vehicleposition"

ehConfig = {}
ehConfig['eventhubs.connectionString'] = connectionString
#You need to encryp connectionstrings
ehConfig['eventhubs.connectionString'] = sc._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(connectionString)

EventHubdf = spark.readStream.format("eventhubs").options(**ehConfig).load()

# COMMAND ----------

display(EventHubdf.limit(10))

# COMMAND ----------

print(EventHubdf.isStreaming)

print(EventHubdf.printSchema())

# COMMAND ----------

jsonSchema=StructType().add("id", StringType()).add("timestamp",TimestampType()).add("rpm", IntegerType()).add("speed", IntegerType()).add("kms", IntegerType())

# COMMAND ----------

#newEventHubDF= EventHubdf.selectExpr("CAST(body as STRING)")

#display(newEventHubDF.limit(20))

# COMMAND ----------

newEventHubDF=newEventHubDF.withColumn("vehicleJSON", from_json(col("body"), schema=jsonSchema))
newEventHubJSONDF= newEventHubDF.select("body", "vehicleJSON.*")
display(newEventHubJSONDF.limit(10))

# COMMAND ----------

# Catch/Persist the data into a storage
newEventHubJSONDeltaDF = newEventHubJSONDF.selectExpr(
                  "id"      \
                  ,"timestamp"       \
                  ,"rpm"    \
                  ,"speed" \
                  ,"kms" ) \
.writeStream.format("delta") \
.outputMode("append") \
.option("checkpointLocation", "dbfs:/vehicleposition/") \
.option("mergeSchema", "true") \
.start("dbfs:/Vehiclechkpoint_AzureEventHub_Delta")

#display(newEventHubJSONDeltaDF.limit(10))

# COMMAND ----------

dbutils.fs.ls("dbfs:/vehicleposition/")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Creating the table on delta location
# MAGIC CREATE TABLE IF NOT EXISTS Vehiclechkpoint_AzureEventHub_Delta
# MAGIC USING DELTA
# MAGIC LOCATION "dbfs:/Vehiclechkpoint_AzureEventHub_Delta"

# COMMAND ----------

# MAGIC %sql
# MAGIC --Check the number of records
# MAGIC 
# MAGIC SELECT COUNT(*) FROM Vehiclechkpoint_AzureEventHub_Delta;
# MAGIC 
# MAGIC SELECT COUNT(DISTINCT(id)) FROM Vehiclechkpoint_AzureEventHub_Delta;
# MAGIC 
# MAGIC --SELECT * FROM Vehiclechkpoint_AzureEventHub_Delta where id="80eea404-d0ef-41ba-a161-fac3e8030dbd" order by timestamp desc;

# COMMAND ----------

#Trigger Every 3 seconds

newEventHubJSONDeltaDF = newEventHubJSONDF.selectExpr(
                  "id"      \
                  ,"timestamp"       \
                  ,"rpm"    \
                  ,"speed" \
                  ,"kms" ) \
.writeStream.format("delta") \
.outputMode("append") \
.option("checkpointLocation", "dbfs:/vehicleposition/") \
.option("mergeSchema", "true") \
.trigger( processingTime='3 seconds')\
.start("dbfs:/Vehiclechkpoint_AzureEventHub_Delta")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Creating the table on delta location
# MAGIC CREATE TABLE IF NOT EXISTS Vehiclechkpoint_AzureEventHub_Delta
# MAGIC USING DELTA
# MAGIC LOCATION "dbfs:/Vehiclechkpoint_AzureEventHub_Delta"