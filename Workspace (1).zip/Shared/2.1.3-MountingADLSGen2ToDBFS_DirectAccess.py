# Databricks notebook source
# MAGIC %md
# MAGIC # Mounting ADLSGen2 storage account onto DBFS with Direct Access

# COMMAND ----------

storageAccount = "carao2023blobadlsgen2"
storageEndPoint = "abfss://rawdata@{}.dfs.core.windows.net".format(storageAccount)

#ClientId, TenantId and Secret is for the Application(ADLSGen2App) was have created as part of this recipe
clientID ="76ab9d9c-90cd-4d1d-8f06-f27293b6c598"
tenantID ="3bf3cf81-25c1-49e5-8989-85ec9cfda95a"
clientSecret ="2vC8Q~CqgqkRL1UM_zLg3kvcALG1OovBBdlkocuY"
oauth2Endpoint = "https://login.microsoftonline.com/{}/oauth2/token".format(tenantID)


# COMMAND ----------

#import the library for defininf schemas
#schemas are data structures - internally Structs
from pyspark.sql.types import *
from  pyspark.sql.functions import sum, avg, max, col


# COMMAND ----------

# create your own schema
cust_schema = StructType(
    [
        StructField("C_CUSTKEY", IntegerType()),
        StructField("C_NAME", StringType()),
        StructField("C_ADDRESS", StringType()),
        StructField("C_NATIONKEY", ShortType()),
        StructField("C_PHONE", StringType()),
        StructField("C_ACCTBAL", DoubleType()),
        StructField("C_MKTSEGMENT", StringType()),
        StructField("C_COMMENT", StringType()),
    ]
)

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.carao2023blobadlsgen2.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.carao2023blobadlsgen2.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.carao2023blobadlsgen2.dfs.core.windows.net", clientID)
spark.conf.set("fs.azure.account.oauth2.client.secret.carao2023blobadlsgen2.dfs.core.windows.net", clientSecret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.carao2023blobadlsgen2.dfs.core.windows.net", oauth2Endpoint)

# COMMAND ----------

df_direct = spark.read.format("csv").option("header", True).schema(cust_schema).load(storageEndPoint+"/customer/csvFiles")
display(df_direct.limit(10))


# COMMAND ----------

# MAGIC %md
# MAGIC # Converting Files into Parquet and Persisting to Storage

# COMMAND ----------

parquetCustomerDestDirect = storageEndPoint+"/customer/parquetFiles"
# read number of partitions
df_direct.rdd.getNumPartitions()
#repartition the dataframe and store it into new Dataframe
df_direct_repart10 = df_direct.repartition(10);
# read number of partitions
df_direct_repart10.rdd.getNumPartitions()
# write the repartitioned file to the destination
df_direct_repart10.write.mode("overwrite").option("header","true").parquet(parquetCustomerDestDirect)

display(dbutils.fs.ls(storageEndPoint+"/customer/parquetFiles"))

# COMMAND ----------

df_direct_parquet = spark.read.format("parquet").option("header", True).schema(cust_schema).load(storageEndPoint+"/customer/parquetFiles")
display(df_direct_parquet.limit(10000))


# COMMAND ----------

#dbutils.fs.ls ("file:/root/")
display(dbutils.fs.mounts())

# COMMAND ----------

# MAGIC %md
# MAGIC # Use SAS Token to connect to Storage 

# COMMAND ----------

storageConnString="fs.azure.sas.rawdata.carao2023blobadlsgen2.blob.core.windows.net"
spark.conf.set(storageConnString, "?sv=2021-06-08&ss=bfqt&srt=s&sp=rwdlacupyx&se=2022-11-23T18:03:29Z&st=2022-11-23T10:03:29Z&spr=https&sig=1iGvoC%2BdB5IkCyTnc7cR0RuZuWEgCP7evJ3ReCwOq%2FA%3D")

# COMMAND ----------

storageEndPointFolders = "{}/customer".format(storageEndPoint)
display(dbutils.fs.ls(storageEndPointFolders))