# Databricks notebook source
# MAGIC %md
# MAGIC # Reading and Writing From and To JSON - Simple and Hierarchical

# COMMAND ----------

storageAccount = "carao2023blobadlsgen2"
mountPoint = "/mnt/SensorData"
storageEndPoint = "abfss://sensordata@{}.dfs.core.windows.net/".format(storageAccount)

#ClientId, TenantId and Secret is for the Application(ADLSGen2App) was have created as part of this recipe
clientID ="76ab9d9c-90cd-4d1d-8f06-f27293b6c598"
tenantID ="3bf3cf81-25c1-49e5-8989-85ec9cfda95a"
clientSecret ="2vC8Q~CqgqkRL1UM_zLg3kvcALG1OovBBdlkocuY"
oauth2Endpoint = "https://login.microsoftonline.com/{}/oauth2/token".format(tenantID)

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": clientID,
           "fs.azure.account.oauth2.client.secret": clientSecret,
           "fs.azure.account.oauth2.client.endpoint": oauth2Endpoint}

try:

    dbutils.fs.mount(
        source=storageEndPoint,
        mount_point=mountPoint,
        extra_configs=configs
    )
except:
    print("Already mounted...."+mountpoint)

# COMMAND ----------

# MAGIC %fs ls dbfs:/mnt/SensorData

# COMMAND ----------

#dbutils.fs.unmount("/mnt/SensorData")

# COMMAND ----------

# MAGIC %fs ls dbfs:/mnt/SensorData/JSONData/SimpleJSONData

# COMMAND ----------

# Read simple json 
df_simpleJson=spark.read.option("multiline", True).json("/mnt/SensorData/JSONData/SimpleJSONData/")

display(df_simpleJson)


# COMMAND ----------

display(df_simpleJson.rdd.getNumPartitions())
df_simpleJson.write.format("json").mode("overwrite").save("/mnt/SensorData/JSONData/SimpleJSONData1/")

# COMMAND ----------

# Read complex json 
df_json=spark.read.option("multiline", True).json("/mnt/SensorData/JSONData/JSONData/")

display(df_json)
display(df_json.printSchema())

# COMMAND ----------

from pyspark.sql.functions import explode

# COMMAND ----------

# Get only the list of owners (name & phone). This can be achieved from explode

data_owners_df = df_json.select("_id", explode("owners").alias("vehicleOwners")).select(
    "_id", "vehicleOwners.name", "vehicleOwners.phone"
)

display(data_owners_df)

# COMMAND ----------

# Try to implode
from pyspark.sql.functions import to_json, col, struct

ownersJSONDF=data_owners_df.withColumn("jsonCol", to_json(struct([data_owners_df[x] for x in data_owners_df.columns]))).select("jsonCol");
display(ownersJSONDF)



# COMMAND ----------

#Choose required fields from original JSON.

selectJSONDF=df_json.withColumn("jsonCol", to_json(struct([df_json["_id"], df_json["color"], df_json["owners.name"], df_json["fuel"]]))).select("jsonCol")

display(selectJSONDF)