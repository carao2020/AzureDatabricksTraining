# Databricks notebook source
# MAGIC %md
# MAGIC # Demo Notebook 

# COMMAND ----------

# MAGIC %fs ls 

# COMMAND ----------

# MAGIC %fs ls /databricks-datasets/

# COMMAND ----------

# MAGIC %fs ls /databricks-datasets/learning-spark-v2/

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating  a dataframe by reading CSV file from path 
# MAGIC # /databricks-datasets/learning-spark-v2/mnm_dataset.csv

# COMMAND ----------

# DBTITLE 0,Load data from CSV file into a dataframe
#load the data from csv into a dataframe
myDataFrame = spark.read.csv(
    "/databricks-datasets/learning-spark-v2/mnm_dataset.csv",
    header="true",
    inferSchema="true",
)
#show will be shown from Dataframe
myDataFrame.show()
#display first 10 records
display(myDataFrame.limit(10))
#print schema of the dataframe
myDataFrame.printSchema()

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES;

# COMMAND ----------

#write the data from dataframe into a table

myDataFrame.write.mode("overwrite").saveAsTable("myCustomTable")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SHOW TABLES;
# MAGIC 
# MAGIC SELECT count(*) FROM mycustomtable;
# MAGIC 
# MAGIC SELECT  * FROM mycustomtable limit 10;