# Databricks notebook source
# MAGIC %md
# MAGIC # Read the customer data from csvFiles on the ADLS Gen2 Database

# COMMAND ----------

# MAGIC %fs ls /mnt/Gen2

# COMMAND ----------

#Read csv file into dataframe

dfSeoulFloating = spark.read.format('csv').options(header='true').load('dbfs:/databricks-datasets/COVID/coronavirusdataset/SeoulFloating.csv')
display(dfSeoulFloating.count())

display (dfSeoulFloating.limit(10))
display (dfSeoulFloating.printSchema())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Connect to COSMOSDB and Create the Database and the Container

# COMMAND ----------

# Install library com.azure.cosmos.spark - azure-cosmos-spark_3-2_2-12 onto cluster
# Create an Azure Cosmos with Provisioned Storage
# create Databasename and container name in CosmosDB
cosmosEndpoint = "https://carao2023azurecosmosdb.documents.azure.com:443/"
cosmosMasterKey = "nuiWJRdzZ7teNVYJerwtbdyHespqu77b155j0a2AjX40NSDUfYxNmUuZbSS06HPHCBg7lx04L4sTACDbZr73wQ=="
cosmosDatabaseName = "Covid"
cosmosContainerName = "SouthKoreaCovid"
spark.conf.set("spark.sql.catalog.cosmosCatalog", "com.azure.cosmos.spark.CosmosCatalog")
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountEndpoint", cosmosEndpoint)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountKey", cosmosMasterKey)
spark.sql("CREATE DATABASE IF NOT EXISTS cosmosCatalog.{};".format(cosmosDatabaseName))
spark.sql("CREATE TABLE IF NOT EXISTS cosmosCatalog.{}.{} using cosmos.oltp TBLPROPERTIES(partitionKeyPath = '/id', manualThroughput = '500')".format(cosmosDatabaseName, cosmosContainerName))

# COMMAND ----------

#Writing DataFrame to Cosmos DB. If the Comos DB RU's are less then it will take quite some time to write 150K records. We are using save mode as append.
#
#Set the write configuration
writeCfg = {
  "spark.cosmos.accountEndpoint": cosmosEndpoint,
  "spark.cosmos.accountKey": cosmosMasterKey,
  "spark.cosmos.database": cosmosDatabaseName,
  "spark.cosmos.container": cosmosContainerName,
  "spark.cosmos.write.strategy": "ItemOverwrite",
}

# COMMAND ----------

#ingest the data
dfSeoulFloating.toDF("date","hour","birth_year","sex","province","city","id")\
   .write\
   .format("cosmos.oltp")\
   .options(**writeCfg)\
   .mode("APPEND")\
   .save()


# COMMAND ----------

#Set the read configuration
readCfg = {
  "spark.cosmos.accountEndpoint": cosmosEndpoint,
  "spark.cosmos.accountKey": cosmosMasterKey,
  "spark.cosmos.database": cosmosDatabaseName,
  "spark.cosmos.container": cosmosContainerName,
  "spark.cosmos.read.inferSchema.enabled" : "false"
}
#Read the data into a Spark dataframe and print the count
query_df = spark.read.format("cosmos.oltp").options(**readCfg).load()
print(query_df.count())

display (query_df.limit(10))
