# Databricks notebook source
# MAGIC %md
# MAGIC # Reading From Apache Kafka

# COMMAND ----------

#imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions  import from_unixtime
from pyspark.sql.functions  import to_date
from pyspark.sql import Row
from pyspark.sql.functions import to_json, struct
from pyspark.sql import functions as F

# COMMAND ----------

# create schema for the Vehicle data json structure
jsonSchema =StructType().add("id", StringType()).add("timestamp", TimestampType()).add("rpm", IntegerType()).add("speed", IntegerType()).add("kms", IntegerType())
 

# COMMAND ----------

# We can use to this to reset the offset from where we want to start reading data from kafak provided data in that offset is available in Kafka Source
offset = '''
  {
  "VehicleDetails":{"0": 1}
  }
'''

# COMMAND ----------

#Reading data from kafka source
kafkaDF = spark.readStream.format("kafka") \
.option("kafka.bootstrap.servers", "20.119.101.82:9092") \
.option("subscribe", "VehicleDetails") \
.option("group.id", "Kafka-Demo") \
.option("startingOffsets","latest" ) \
.load()


# COMMAND ----------

#Converting binary datatype to string for the dataframe columns. Without this you cannot use from_json function as it expects the column datatype as string not binary
newkafkaDF=kafkaDF.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")

display(newkafkaDF.limit(10))
newkafkaDF.printSchema()
